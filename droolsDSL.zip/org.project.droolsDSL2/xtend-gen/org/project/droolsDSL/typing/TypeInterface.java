package org.project.droolsDSL.typing;

@SuppressWarnings("all")
public interface TypeInterface {
  public abstract String toString();
}
