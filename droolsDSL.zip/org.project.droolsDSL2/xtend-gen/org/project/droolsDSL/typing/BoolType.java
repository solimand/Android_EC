package org.project.droolsDSL.typing;

import org.project.droolsDSL.typing.TypeInterface;

@SuppressWarnings("all")
public class BoolType implements TypeInterface {
  public String toString() {
    return "boolean";
  }
}
