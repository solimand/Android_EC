package org.project.droolsDSL.typing;

import org.project.droolsDSL.typing.TypeInterface;

@SuppressWarnings("all")
public class IntType implements TypeInterface {
  public String toString() {
    return "int";
  }
}
