/**
 */
package org.project.droolsDSL.ddsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>At Expr</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.project.droolsDSL.ddsl.DdslPackage#getAtExpr()
 * @model
 * @generated
 */
public interface AtExpr extends EObject
{
} // AtExpr
