/**
 */
package org.project.droolsDSL.ddsl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Condition Rule</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.project.droolsDSL.ddsl.DdslPackage#getConditionRule()
 * @model
 * @generated
 */
public interface ConditionRule extends EObject
{
} // ConditionRule
