/**
 */
package org.project.droolsDSL.ddsl.impl;

import org.eclipse.emf.ecore.EClass;

import org.project.droolsDSL.ddsl.DdslPackage;
import org.project.droolsDSL.ddsl.Not;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Not</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class NotImpl extends ExpressionImpl implements Not
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected NotImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return DdslPackage.Literals.NOT;
  }

} //NotImpl
