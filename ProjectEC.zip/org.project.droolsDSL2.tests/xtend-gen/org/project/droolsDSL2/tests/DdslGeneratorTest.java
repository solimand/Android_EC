package org.project.droolsDSL2.tests;

import org.eclipse.xtext.junit4.InjectWith;
import org.eclipse.xtext.junit4.XtextRunner;
import org.junit.runner.RunWith;
import org.project.droolsDSL.DdslInjectorProvider;

@RunWith(XtextRunner.class)
@InjectWith(DdslInjectorProvider.class)
@SuppressWarnings("all")
public class DdslGeneratorTest {
}
