/**
 */
package org.project.droolsDSL.ddsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Not</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.project.droolsDSL.ddsl.DdslPackage#getNot()
 * @model
 * @generated
 */
public interface Not extends Expression
{
} // Not
