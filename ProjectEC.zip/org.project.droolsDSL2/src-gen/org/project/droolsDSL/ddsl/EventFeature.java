/**
 */
package org.project.droolsDSL.ddsl;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.project.droolsDSL.ddsl.DdslPackage#getEventFeature()
 * @model
 * @generated
 */
public interface EventFeature extends ReferenceType
{
} // EventFeature
