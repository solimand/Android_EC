/**
 */
package org.project.droolsDSL.ddsl.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.project.droolsDSL.ddsl.DdslPackage;
import org.project.droolsDSL.ddsl.ToRule;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>To Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ToRuleImpl extends MinimalEObjectImpl.Container implements ToRule
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected ToRuleImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return DdslPackage.Literals.TO_RULE;
  }

} //ToRuleImpl
