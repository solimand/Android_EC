/**
 */
package org.project.droolsDSL.ddsl.impl;

import org.eclipse.emf.ecore.EClass;

import org.project.droolsDSL.ddsl.DdslPackage;
import org.project.droolsDSL.ddsl.EventFeature;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class EventFeatureImpl extends ReferenceTypeImpl implements EventFeature
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EventFeatureImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return DdslPackage.Literals.EVENT_FEATURE;
  }

} //EventFeatureImpl
