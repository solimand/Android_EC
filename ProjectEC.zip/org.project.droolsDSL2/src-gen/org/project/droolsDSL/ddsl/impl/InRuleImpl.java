/**
 */
package org.project.droolsDSL.ddsl.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.project.droolsDSL.ddsl.DdslPackage;
import org.project.droolsDSL.ddsl.InRule;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>In Rule</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class InRuleImpl extends MinimalEObjectImpl.Container implements InRule
{
  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected InRuleImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  @Override
  protected EClass eStaticClass()
  {
    return DdslPackage.Literals.IN_RULE;
  }

} //InRuleImpl
