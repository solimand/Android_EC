package org.project.droolsDSL.utils;

@SuppressWarnings("all")
public class DdslModelUtil {
}
