package org.project.droolsDSL.javaModel;


public interface EffectDescr extends ContextDescr{
    public ContextDescr getContext();
    public String getFluent();
}
